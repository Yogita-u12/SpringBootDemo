package com.ttl.SpringBootDemoProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootDemoProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
